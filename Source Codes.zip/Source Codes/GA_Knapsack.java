// Genetic solution for the 0/1 knapsack problem
package ga_knapsack;

import java.util.ArrayList;
import java.util.Random;

public class GA_Knapsack {

    public static void main(String[] args) {

        int C = 50; // The knapsack weight capacity

        int items_weights[] = new int[]{10, 20, 30}; // Weights of the items
        int items_values[] = new int[]{60, 100, 120}; // Values of the items
        int n_items = items_values.length; // No. of items
        
        // Info for the genetic degree of optimization
        int population_size = 150;
        int max_generations = 200;
        double cross_probability = 0.5;
        double mutation_probability = 0.015;

        // Initialize the knapsack and GA variables
        Knapsack ks = new Knapsack(C, items_weights, items_values, n_items, population_size, max_generations, cross_probability, mutation_probability);
        
        ks.Solve_GA_Knapsack();
        
    }

}

class Knapsack {

    // Knapsack variables
    private final int max_capacity;
    private final int[] weights;
    private final int[] values;
    private final int no_of_items; // Represents the chromosome length (solution string no. of bits)

    // GA variables
    private final int no_of_candidates; // Equivilant to population size
    private final int max_generations;
    private final double crossover_probability;
    private final double mutation_probability;
    private int best_fitness;
    private ArrayList<String> candidate_solutions;

    // Now we need to initialize all these variables
    public Knapsack(int max_capacity, int[] weights, int[] values, int no_of_items, int population_size, int max_generations, double crossover_probability, double mutation_probability) {

        // Knapsack variables
        this.max_capacity = max_capacity;
        this.weights = weights;
        this.values = values;
        this.no_of_items = no_of_items;

        // GA variables
        this.no_of_candidates = population_size;
        this.max_generations = max_generations;
        this.crossover_probability = crossover_probability;
        this.mutation_probability = mutation_probability;
        candidate_solutions = new ArrayList<>();
    }

    // The main solution logic function
    // Returns the max value that can be put in a knapsack of C capacity
    public void Solve_GA_Knapsack() {

        // First of all, we initialize the first generation
        GenerateSolutions(no_of_candidates);

        // Run the GA and keep creating new generations until required fitness achieved
        for (int g = 0; (g < max_generations) && (best_fitness < max_capacity); g++) {
            System.out.print("Generation: " + (g + 1));
            System.out.print(" " + "----- Best chromosome(solution string):" + GetGenBestSolution());
            System.out.println(" " + "----- Best soution value:" + best_fitness);
            GenerateNewGeneration();
        }
    }
    
    // This function is the main player for the process
    // It takes the two best candidate solutions of a generation
    // as parents to create a new generation using crossover
    // then mutating the new generation
    private void GenerateNewGeneration(){
        
        String f_candidate = GetGenBestSolution(); // First best candidate solution
        
        // In order to get the second best solution
        // If we removed the best one from the solutions list
        // we then get the second one
        candidate_solutions.remove(f_candidate);
        
        // First best candidate solution now in the list
        // Which actually is the second best for current generation
        String s_candidate = GetGenBestSolution();
        
        // Create the new generation
        candidate_solutions = new ArrayList<>();
        
        // Add the best solution we got so far
        candidate_solutions.add(f_candidate);
        
        // Applying crossover and utation
        // to create all new offsprings in the new generation
        // Taking in consideration the max limit for the population
        for(int i = 1; i < no_of_candidates; i++){
            candidate_solutions.add(Mutate(Crossover(f_candidate, s_candidate)));
        }
    }

    // Method to generates all solution candidates for the first generation
    private void GenerateSolutions(int n_candidates) {

        Random rand = new Random(System.currentTimeMillis());

        String candidate;
        
        for (int i = 0; i < n_candidates; i++) {
            candidate = "";

            // Randomly assign a 0 or 1 value to items
            // As 1 means item will be picked, 0 means hard luck (item we be leaved)
            for (int j = 0; j < no_of_items; j++) {
                int ch = rand.nextInt(2);
                candidate += ch;
            }

            // Add the randomly formed candidate solution to the generation
            candidate_solutions.add(candidate);
        }
    }
    
    // Method to calculate the fitness function for a candidate solution
    // In order to pick the most fit ones to produce next generations later
    private int Calculate_Fitness(String candidate_solution) {

        int fitness = 0;
        int w = 0;

        // Iterating over all genes of the candidate solution
        for (int i = 0; i < candidate_solution.length(); i++) {

            // If gene is 1, the item is picked into the knapsack
            if (candidate_solution.charAt(i) == '1') {
                w += weights[i];
                fitness += values[i];
            }
        }

        // Return the fitness for this candidate solution
        // only if max knapsack capacity hasn't been exceeded
        // Else return -1
        if (w <= max_capacity) {
            return fitness;
        } else {
            return -1;
        }
    }

    // The crossover method
    // Two potentially best candidate solutions to generate new offsprings
    // taking in consideration the crossover probability
    private String Crossover(String f_candidate, String s_candidate) {

        String crossed_over = "";

        // Iterating over the genes of a chromosome (candidate solution)
        for (int i = 0; i < f_candidate.length(); i++) {

            if (Math.random() >= crossover_probability) {
                crossed_over += f_candidate.charAt(i);
            } else {
                crossed_over += s_candidate.charAt(i);
            }
        }

        return crossed_over;
    }

    // The mutation method
    // Mutating the genes of a given candidate solution
    // taking in consideration the mutation probability
    private String Mutate(String candidate_solution) {

        // Iterating over the genes of the chromosome (candidate solutio)
        for (int i = 0; i < candidate_solution.length(); i++) {
            // Checking randomly whether to mutate the current
            // gene of the iteration
            if (Math.random() <= mutation_probability) {
                candidate_solution = FlipBit(i, candidate_solution);
            }
        }

        // Return the mutated candidate solution
        return candidate_solution;
    }

    // Method used for mutation
    // Flips gene bits (solution string) of a chromosome (candidate solution)
    private String FlipBit(int ix, String candidate_solution) {
        
        String return_new_string = "";
        for (int i = 0; i < candidate_solution.length(); i++) {
            if (i == ix) {
                if (candidate_solution.charAt(i) == '1') {
                    return_new_string += 0;
                } else {
                    return_new_string += 1;
                }
            } else {
                return_new_string += candidate_solution.charAt(i);
            }
        }
        return return_new_string;
    }
    
    // Candidate solution fitness setter
    private void SetBestFit(int new_best_fitness) {
        this.best_fitness = new_best_fitness;
    }
    
    // Method to get the best solution among the generation
    // Here is where we apply the natural selection principle
    private String GetGenBestSolution(){
        
        int best_fit = -1;
        String best_solution = null;
        
        // Iterating over all the generation to find the best fit solution
        for (String candidate_solution : candidate_solutions) {
            int new_fit = Calculate_Fitness(candidate_solution);
            if(new_fit != -1){
                // If we find a better fit solution
                // update best solution to the fitter one
                if (new_fit >= best_fit) {
                    best_solution = candidate_solution;
                    best_fit = new_fit;
                }
            }
        }
        SetBestFit(best_fit);
        
        // Return the best candidate solution of current generation
        return best_solution;
    }
    
}
