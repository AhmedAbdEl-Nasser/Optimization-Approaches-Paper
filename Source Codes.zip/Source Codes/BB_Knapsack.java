package bb_knapsack;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Queue;
import java.util.LinkedList;

public class BB_Knapsack {

    public static void main(String[] args) {

        int max_capacity = 50;
        Item items[] = {new Item(10, 60), new Item(20, 100), new Item(30, 120)};
        int no_of_items = items.length;

        Knapsack ks = new Knapsack(50, items, no_of_items);

        // The solution of the problem
        // Max value that can be picked to include in the knapsack
        int solution = ks.Solve_BB_Knapsack();
        System.out.println(solution);
    }
}

class Item {

    private final int weight, value;

    public Item(int weight, int value) {
        this.weight = weight;
        this.value = value;
    }

    public int getWeight() {
        return weight;
    }

    public int getValue() {
        return value;
    }

}

class Knapsack {

    // Knapsack variables
    private final int max_capacity;
    private final Item items[];
    private final int no_of_items;

    public Knapsack(int max_capacity, Item[] items, int no_of_items) {
        this.max_capacity = max_capacity;
        this.items = items;
        this.no_of_items = no_of_items;
    }

    int Solve_BB_Knapsack() {

        // Sorting items in descendingly
        // based on value per unit weight
        Arrays.sort(items, new CompareCriteria());

        Queue<BBTreeNode> q = new LinkedList<>();
        BBTreeNode u = new BBTreeNode();
        BBTreeNode v = new BBTreeNode();

        // Start with a dummy node
        u.setLevel(-1);
        u.setValue(0);
        u.setWeight(0);
        q.add(u);

        // Extract items from decision tree one by one 
        // compute value of all children of each extracted item 
        // keeping track of max value to return as the solution
        int max_value = 0; // The solution
        while (!q.isEmpty()) {
            u = q.peek();
            q.remove();

            if (u.getLevel() == -1) {
                v.setLevel(0);
            }

            if (u.getLevel() == no_of_items - 1) {
                continue;
            }

            v.setLevel(u.getLevel() + 1);

            v.setWeight(u.getWeight() + items[v.getLevel()].getWeight());
            v.setValue(u.getValue() + items[v.getLevel()].getValue());

            // update new max value if a greater one was found
            if ((v.getWeight() <= max_capacity) && (v.getValue() > max_value)) {
                max_value = v.getValue();
            }

            v.setBound(Bound(v));

            if (v.getBound() > max_value) {
                q.add(v);
            }

            v.setWeight(u.getWeight());
            v.setValue(u.getValue());
            v.setBound(Bound(v));
            if (v.getBound() > max_value) {
                q.add(v);
            }
        }

        return max_value;
    }

    // Method to set the upper bound on maximum value
    private int Bound(BBTreeNode node) {

        // if weight exceeds the knapsack max capacity 
        // return 0 as expected bound
        if (node.getWeight() >= max_capacity) {
            return 0;
        }

        // initialize bound on value with the current one 
        int value_bound = node.getValue();

        int i = node.getLevel() + 1;
        int total_weight = node.getWeight();

        // Check the index condition and knapsack max capacity
        while ((i < no_of_items) && (total_weight + items[i].getWeight() <= max_capacity)) {
            total_weight += items[i].getWeight();
            value_bound += items[i].getValue();
            i++;
        }

        if (i < no_of_items) {
            value_bound += (max_capacity - total_weight) * items[i].getValue() / items[i].getValue();
        }

        return value_bound;
    }

}

// Define a new sort rule for items based on the ratio between value/weght
class CompareCriteria implements Comparator<Item> {

    // Comparison method for sorting items descendingly
    // with respect to their value/weight ratio
    @Override
    public int compare(Item item1, Item item2) {
        return (item2.getValue() / item2.getWeight()) - (item1.getValue() / item1.getWeight());
    }

}

// Tree node structure to store decision tree information
class BBTreeNode {

    private int weight, value;
    private int level, bound;

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public void setBound(int bound) {
        this.bound = bound;
    }

    public int getWeight() {
        return weight;
    }

    public int getValue() {
        return value;
    }

    public int getLevel() {
        return level;
    }

    public int getBound() {
        return bound;
    }

}
