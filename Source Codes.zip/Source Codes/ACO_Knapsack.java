package aco_knapsack;

import java.util.Random;

public class ACO_Knapsack {

    public static void main(String[] args) {

        int C = 50; // The knapsack weight capacity

        int items_weights[] = new int[]{10, 20, 30}; // Weights of the items
        int items_values[] = new int[]{60, 100, 120}; // Values of the items
        int n_items = items_values.length; // No. of items

        int no_of_ants = 500;

        // Initialize the knapsack and GA variables
        Knapsack ks = new Knapsack(C, items_weights, items_values, n_items, no_of_ants);

        // The solution of the problem
        // Max value that can be picked to include in the knapsack
        int solution = ks.Solve_AOC_Knapsack();

        System.out.println(solution);

    }

}

class Knapsack {

    // Knapsack variables
    private final int max_capacity;
    private final int[] weights;
    private final int[] values;
    private final int no_of_items;

    // AOC algorithm variables
    private final int no_of_ants;

    public Knapsack(int max_capacity, int[] weights, int[] values, int no_of_items, int no_of_ants) {

        // Knapsack variables
        this.max_capacity = max_capacity;
        this.weights = weights;
        this.values = values;
        this.no_of_items = no_of_items;

        // AOC algorithm variables
        this.no_of_ants = no_of_ants;
    }

    public int Solve_AOC_Knapsack() {

        int max_value = 0; // The solution

        double x[] = new double[no_of_items];
        double y[] = new double[no_of_items];

        for (int i = 0; i < no_of_items; i++) {
            x[i] = 1;
            y[i] = values[i] / weights[i];
        }

        int ni = no_of_items;
        int na = no_of_ants;
        while (na > 0) {
            while (ni > 0) {

                int C = max_capacity;
                int N[] = new int[no_of_items];
                int current_value = 0; // current solution value to be compared with max_value

                for (int j = 0; j < no_of_items; j++) {
                    N[j] = 0;
                }

                int i = 0;
                while (C > 0 && i < no_of_items) {
                    if (GetNextBool(Probability(N, i, x, y, ni)) == 1) {
                        N[i] = 1;
                        C = C - weights[i];
                        current_value += values[i];
                    }
                    i++;
                }

                //Update max value solution
                if (current_value > max_value) {
                    max_value = current_value;
                }

                for (int j = 0; j < no_of_items; j++) {
                    if (N[j] == 1) {
                        x[j] += 1 / (1 + ((max_value - current_value) / max_value));
                    } else {
                        x[j] = x[j] * 0.6;
                    }
                }

                ni--;
            }
            na--;
        }
        return max_value;
    }

    private final Random RANDOM = new Random(1);

    private int GetNextBool(double probability) {
        return (RANDOM.nextInt()) < probability * ((double) Integer.MAX_VALUE + 1.0) ? 1 : 0;
    }

    private double Probability(int N[], int k, double x[], double y[], int no_of_items) {

        double s = 0;

        for (int i = 0; i < no_of_items; i++) {
            if (N[i] == 1) {
                s += x[i] * y[i];
            }
        }

        return (x[k] * y[k]) / s;

    }

}
