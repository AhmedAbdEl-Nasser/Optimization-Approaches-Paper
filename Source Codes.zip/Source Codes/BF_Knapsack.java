package bf_knapsack;

public class BF_Knapsack {

    public static void main(String[] args) {

        int C = 50; // The knapsack weight capacity

        int items_weights[] = new int[]{10, 20, 30}; // Weights of the items
        int items_values[] = new int[]{60, 100, 120}; // Values of the items
        int n_items = items_values.length; // No. of items

        Knapsack ks = new Knapsack();

        // The solution of the problem
        // Max value that can be picked to include in the knapsack
        int solution = ks.Solve_BF_Knapsack(n_items, items_weights, items_values, C);

        System.out.println(solution);
    }
}

class Knapsack {

    public int Solve_BF_Knapsack(int no_of_items, int weights[], int values[], int max_capacity) {

        // Brute force algorithm variables
        int max_value = 0; // The solution (maximum value to pick in the knapsack)

        if (no_of_items == 0 || max_capacity == 0) {
            return 0;
        }

        if (weights[no_of_items - 1] > max_capacity) {
            return Solve_BF_Knapsack(no_of_items - 1, weights, values, max_capacity);
        } else {
            return maximum_of(values[no_of_items - 1] + Solve_BF_Knapsack(no_of_items - 1, weights, values, max_capacity - weights[no_of_items - 1]),
                    Solve_BF_Knapsack(no_of_items, weights, values, no_of_items - 1));
        }
    }

    // A method that simply compare two items
    // and return the larger one of them
    private int maximum_of(int first, int second) {
        if (first > second) {
            return first;
        } else {
            return second;
        }
    }
}
