// Dynamic programming solution for the 0/1 knapsack problem
package dp_knapsack;

public class DP_Knapsack {

    // Testing the knapsack DP function
    public static void main(String[] args) {

        int C = 50; // The knapsack weight capacity

        int items_weights[] = new int[]{10, 20, 30}; // Weights of the items
        int items_values[] = new int[]{60, 100, 120}; // Values of the items
        int n_items = items_values.length; // No. of items

        // Initialize the knapsack and GA variables
        Knapsack ks = new Knapsack(C, items_weights, items_values, n_items);

        // The solution of the problem
        // Max value that can be picked to include in the knapsack
        int solution = ks.Solve_DP_Knapsack();

        System.out.println(solution);
    }

}

class Knapsack {

    // Knapsack variables
    private final int max_capacity;
    private final int[] weights;
    private final int[] values;
    private final int no_of_items;

    // DP algorithm variables
    private final int K[][]; // Sub-problems Table

    public Knapsack(int max_capacity, int[] weights, int[] values, int no_of_items) {
        this.max_capacity = max_capacity;
        this.weights = weights;
        this.values = values;
        this.no_of_items = no_of_items;
        K = new int[no_of_items + 1][max_capacity + 1];
    }

    // The main solution logic function
    // Returns the max value that can be put in a knapsack of C capacity
    // Using the buttom-up appraoch (tabulization)
    public int Solve_DP_Knapsack() {

        // Buiding the table of sub solutions then return the max value in it as the optimal solution
        for (int i = 0; i <= no_of_items; i++) {
            for (int c = 0; c <= max_capacity; c++) {
                if (i == 0 || c == 0) {
                    K[i][c] = 0;
                } else if (weights[i - 1] <= c) {
                    if ((values[i - 1] + K[i - 1][c - weights[i - 1]]) > (K[i - 1][c])) {
                        K[i][c] = (values[i - 1] + K[i - 1][c - weights[i - 1]]);
                    } else {
                        K[i][c] = (K[i - 1][c]);
                    }
                } else {
                    K[i][c] = (K[i - 1][c]);
                }
            }
        }

        return K[no_of_items][max_capacity];
    }

}
